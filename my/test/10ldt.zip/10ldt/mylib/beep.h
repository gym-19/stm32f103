#ifndef __BEEP_H
#define __BEEP_H

#include "stm32f10x_conf.h"
/*
beep pc7
�ߵ�ƽ
*/

extern void beep_init(void);//��ʼ��

extern void beep_on(void);//��

extern void beep_off(void);//��


#endif




