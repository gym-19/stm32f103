#include "key.h"
#include "bitband.h"
void key_init(void)//��ʼ��led
{
	GPIO_InitTypeDef Gpio_Value;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC | RCC_APB2Periph_GPIOA, ENABLE);
	//ͨ��APB2����ʹ��ʱ��
	//����
	//key1->KEY0->PC8
	Gpio_Value.GPIO_Mode = GPIO_Mode_IPU;
	Gpio_Value.GPIO_Pin = GPIO_Pin_9 |GPIO_Pin_8;
	GPIO_Init(GPIOC,  &Gpio_Value);//��ʼ��gpioc�ܽ�
	
	
	Gpio_Value.GPIO_Mode = GPIO_Mode_IPD;
	Gpio_Value.GPIO_Pin = GPIO_Pin_0;
	GPIO_Init(GPIOA,  &Gpio_Value);//��ʼ��gpioa�ܽ�
	
}
int key_on(int nu)//����
{
	int a;
	 switch(nu)
	{
		case 1: a = PCIn(9);break;
		case 2: a = PCIn(8);break;
		case 3: a = PAIn(0);break;
		default: return 0;
	}
		
		return a;
}














